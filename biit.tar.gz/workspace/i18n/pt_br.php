<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 05/12/14
 * Time: 15:57
 */
define("GO", "Ir!");
define("HELLO", "Bem vindo ao Website Revista PHP");