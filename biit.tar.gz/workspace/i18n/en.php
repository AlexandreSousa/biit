<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 05/12/14
 * Time: 15:57
 */
define("GO", "Go!");
define("HELLO", "Welcome to the  Revista PHP website");